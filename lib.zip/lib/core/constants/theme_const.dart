import 'package:flutter/material.dart';

const primaryColor = Color(0xFF1A73E8); 