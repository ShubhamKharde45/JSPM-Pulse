class UserEntity {
  final String? email;
  final String id;
  

  UserEntity({this.email, required this.id});
}
